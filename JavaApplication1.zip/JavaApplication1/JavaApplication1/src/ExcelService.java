

import java.awt.print.Book;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class ExcelService {

public ExcelService()
{
	
}
public List<MailBean> readBooksFromExcelFile(String excelFilePath) throws IOException {
        List<MailBean> mailList = new ArrayList<>();
        FileInputStream inputStream = new FileInputStream(new File(excelFilePath));

        Workbook workbook = new XSSFWorkbook(inputStream);
        Sheet firstSheet = workbook.getSheetAt(0);
        Iterator<Row> iterator = firstSheet.iterator();
        iterator.next();
        while (iterator.hasNext()) {
            Row nextRow = iterator.next();
            Iterator<Cell> cellIterator = nextRow.cellIterator();
            MailBean mail = new MailBean();

            while (cellIterator.hasNext()) {
                Cell nextCell = cellIterator.next();
                int columnIndex = nextCell.getColumnIndex();

                switch (columnIndex) {
                    case 0:
                        mail.setToAddress(readCell(nextCell));
                        break;
                    case 1:
                        mail.setSubject(readCell(nextCell));
                        break;
                    case 2:
                        mail.setMessage(readCell(nextCell));
                        break;
                }

            }
            mailList.add(mail);
        }
            
        inputStream.close();
        
        return mailList;
    }
private String readCell(Cell cell)
{
    String content;
    switch (cell.getCellType()) {
        case Cell.CELL_TYPE_STRING:
            content=cell.getStringCellValue();
            break;
        case Cell.CELL_TYPE_BOOLEAN:
          content=String.valueOf(cell.getBooleanCellValue());
            break;
        case Cell.CELL_TYPE_NUMERIC:
            content=String.valueOf(cell.getNumericCellValue());
            break;
        case Cell.CELL_TYPE_FORMULA:
            content=cell.getCellFormula();
            break;
        default:
            content=String.valueOf(cell.getDateCellValue());
    }

    return content;
}

}